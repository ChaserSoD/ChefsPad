const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const allRecipeFolderPath = path.join(__dirname, "storage", "recipeList");
const userRecipeFolderPath = path.join(__dirname, "storage", "userRecipeList");
const savedRecipeFolderPath = path.join(__dirname, "storage", "savedRecipeList");

// Method to read an event from a file

function get(input) {
  try {
    const files = fs.readdirSync(allRecipeFolderPath);
    const matchingRecipes = [];

    for (let file of files) {
      const filePath = path.join(allRecipeFolderPath, file);
      const fileData = fs.readFileSync(filePath, "utf8");
      const recipe = JSON.parse(fileData);

      if (typeof input === 'string') {
        // If the input is a string, check if it matches the recipe's name or id
        if (recipe.name.toLowerCase().includes(input.toLowerCase()) || recipe.id === input) {
          matchingRecipes.push(recipe);
        }
      } else if (Array.isArray(input)) {
        // If the input is an array (like ingredients), check if every element of input is in the recipe's ingredients
        if (input.every(ing => recipe.ingredients.includes(ing))) {
          matchingRecipes.push(recipe);
        }
      }
    }

    return matchingRecipes.length > 0 ? matchingRecipes : null;
  } catch (error) {
    throw { code: "failedToReadRecipe", message: error.message };
  }
}

// Method to write a recipe to a file
function create(recipe) {
  try {
    recipe.id = crypto.randomBytes(16).toString("hex");
    const filePathAll = path.join(allRecipeFolderPath, `${recipe.id}.json`);
    const filePathUser = path.join(userRecipeFolderPath, `${recipe.id}.json`);
    const fileData = JSON.stringify(recipe);
    fs.writeFileSync(filePathAll, fileData, "utf8");
    fs.writeFileSync(filePathUser, fileData, "utf8");
    return recipe;
  } catch (error) {
    throw { code: "failedToCreateRecipe", message: error.message };
  }
}

// Method to copy a recipe to another file
function copy(id) {
  try {
    const filePath = path.join(allRecipeFolderPath, `${id}.json`);

    // Check if the recipe exists in allRecipeFolderPath
    if (!fs.existsSync(filePath)) {
      throw { code: "recipeNotFound", message: `Recipe ${id} not found` };
    }

    const fileData = fs.readFileSync(filePath, "utf8");
    const recipe = JSON.parse(fileData);

    // Check if the recipe already exists in savedRecipeFolderPath
    const filePathSaved = path.join(savedRecipeFolderPath, `${id}.json`);
    if (fs.existsSync(filePathSaved)) {
      throw { code: "duplicateRecipe", message: `Recipe ${recipe.name} already exists in saved recipes` };
    }

    // Copy the recipe to savedRecipeFolderPath
    fs.writeFileSync(filePathSaved, fileData, "utf8");

    return recipe;
  } catch (error) {
    throw { code: "failedToCopyRecipe", message: error.message };
  }
}

// Method to update recipe in a file
function update(id, recipe) {
  try {
    const currentRecipe = get(id);

    if (!currentRecipe) return null;

    const newRecipe = { ...currentRecipe, ...recipe };

    const fileData = JSON.stringify(newRecipe);

    const filePathAll = path.join(allRecipeFolderPath, `${id}.json`);
    if (fs.existsSync(filePathAll)) {
      fs.writeFileSync(filePathAll, fileData, "utf8");
    }

    const filePathUser = path.join(userRecipeFolderPath, `${id}.json`);
    if (fs.existsSync(filePathUser)) {
      fs.writeFileSync(filePathUser, fileData, "utf8");
    }

    const filePathSaved = path.join(savedRecipeFolderPath, `${id}.json`);
    if (fs.existsSync(filePathSaved)) {
      fs.writeFileSync(filePathSaved, fileData, "utf8");
    }

    return newRecipe;
  } catch (error) {
    throw { code: "failedToUpdateRecipe", message: error.message };
  }
}

// Method to remove an recipe from a file
function remove(recipeId, type) {
  try {
    if (type === 'all') {
      fs.unlinkSync(path.join(userRecipeFolderPath, `${recipeId}.json`));
      fs.unlinkSync(path.join(allRecipeFolderPath, `${recipeId}.json`));
    } else if (type === 'saved') {
      fs.unlinkSync(path.join(savedRecipeFolderPath, `${recipeId}.json`));
    } else {
      throw { code: "invalidType", message: "Type must be either 'user', 'all' or 'saved'" };
    }
    return {};
  } catch (e) {
    if (e.code === "ENOENT") {
      return {};
    } else {
      throw new Error("failedToRemoveRecipe");
    }
  }
}

// Method to list recipes in a folder
function list(type) {
  try {
    let folderPath;
    if (type === 'user') {
      folderPath = userRecipeFolderPath;
    } else if (type === 'saved') {
      folderPath = savedRecipeFolderPath;
    } else {
      throw { code: "invalidType", message: "Type must be either 'user' or 'saved'" };
    }

    const files = fs.readdirSync(folderPath);
    const recipeList = files.map((file) => {
      const fileData = fs.readFileSync(
        path.join(folderPath, file),
        "utf8"
      );
      return JSON.parse(fileData);
    });
    recipeList.sort((a, b) => a.name.localeCompare(b.name));
    return recipeList;
  } catch (error) {
    throw { code: "failedToListRecipes", message: error.message };
  }
}

module.exports = {
  get,
  create,
  update,
  remove,
  list,
  copy,
};
