const Ajv = require("ajv");
const addFormats = require("ajv-formats").default;
const ajv = new Ajv();
addFormats(ajv);

const recipeDao = require("../../dao/library-dao.js");

const schema = {
  type: "object",
  properties: {
    id: { type: "string", minLength: 32, maxLength: 32 },
    name: { type: "string", minLength: 2 },
    ingredients: { type: "array", items: { type: "string" } },
    instructions: { type: "string" },
  },
  required: ["id"],
  additionalProperties: false,
};

async function UpdateAbl(req, res) {
  try {
    let recipeData = req.body;

    const valid = ajv.validate(schema, recipeData);
    if (!valid) {
      res.status(400).json({
        code: "dtoInIsNotValid",
        message: "dtoIn is not valid",
        validationError: ajv.errors,
      });
      return;
    }

    const updatedRecipe = await recipeDao.update(recipeData.id, recipeData);

    if (!updatedRecipe) {
      res.status(404).json({
        code: "recipeNotFound",
        message: `Recipe ${recipeData.id} not found`,
      });
      return;
    }

    res.json(updatedRecipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}
module.exports = UpdateAbl;