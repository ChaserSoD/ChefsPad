
const recipeDao = require("../../dao/library-dao.js");

async function ListAbl(req, res) {
  try {
    const type = req.query.type; 
    const recipeList = await recipeDao.list(type); 
    res.json(recipeList);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

module.exports = ListAbl;