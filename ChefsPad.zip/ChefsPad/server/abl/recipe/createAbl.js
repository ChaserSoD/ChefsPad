const Ajv = require("ajv");
const addFormats = require("ajv-formats").default;
const ajv = new Ajv();
addFormats(ajv);

const recipeDao = require("../../dao/library-dao.js");
const ingredientList = require("../../dao/storage/ingredientList.js");

const schema = {
  type: "object",
  properties: {
    name: { type: "string", minLength: 2 },
    ingredients: { type: "array", items: { type: "string" } },
    instructions: { type: "string" },
  },
  required: ["name", "ingredients", "instructions"],
  additionalProperties: false,
};

async function CreateAbl(req, res) {
  try {
    let recipe = req.body;

    // validate input
    const valid = ajv.validate(schema, recipe);
    if (!valid) {
      res.status(400).json({
        code: "dtoInIsNotValid",
        message: "dtoIn is not valid",
        validationError: ajv.errors,
      });
      return;
    }
   
   // compare ingredients
   const missingIngredients = recipe.ingredients.filter(ingredient => 
    typeof ingredient === 'string' && 
    !ingredientList.map(i => i && typeof i === 'string' ? i.toLowerCase() : '').includes(ingredient.toLowerCase())
  );
  if (missingIngredients.length > 0) {
    res.status(400).json({
      code: "wrongIngredients",
      message: `The following ingredients are not in the ingredient list: ${missingIngredients.join(', ')}`,
    });
    return;
  }
   
    recipe = await recipeDao.create(recipe);
    res.json(recipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

module.exports = CreateAbl;