const Ajv = require("ajv");
const addFormats = require("ajv-formats").default;
const ajv = new Ajv();
addFormats(ajv);

const recipeDao = require("../../dao/library-dao.js");

const schema = {
  type: "object",
  properties: {
    id: { type: "string", minLength: 2 },
    name: { type: "string", minLength: 2 },
    ingredients: { type: "array", items: { type: "string" } },
  },
  oneOf: [
    { required: ["id"] },
    { required: ["name"] },
    { required: ["ingredients"] },
  ],
  additionalProperties: false,
};

async function GetAbl(req, res) {
  try {
    // get request query or body
    const reqParams = req.query?.id || req.query?.name || req.query?.ingredients ? req.query : req.body;

    // validate input
    const valid = ajv.validate(schema, reqParams);
    if (!valid) {
      res.status(400).json({
        code: "dtoInIsNotValid",
        message: "dtoIn is not valid",
        validationError: ajv.errors,
      });
      return;
    }

    // read recipe by given id, name or ingredients
    const recipe = reqParams.id ? recipeDao.get(reqParams.id) : reqParams.name ? recipeDao.get(reqParams.name) : recipeDao.get(reqParams.ingredients);
    if (!recipe) {
      res.status(404).json({
        code: "recipeNotFound",
        message: `Recipe ${reqParams.id || reqParams.name || reqParams.ingredients.join(', ')} not found`,
      });
      return;
    }

    res.json(recipe);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

module.exports = GetAbl;